function Welcome() {
  return <h2>Welcome to my website!</h2>;
}


function App(){

return (
  <div>
    <h1>Hello</h1>
      <p>My first React application.</p>
    <p>Welcome</p>
  </div>
);

}
export default App;
