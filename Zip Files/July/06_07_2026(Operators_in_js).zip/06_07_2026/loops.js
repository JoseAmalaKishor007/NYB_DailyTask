//while loop

for(let i=1;i<5;i++){
    console.log(i);
}


let fruit=["apple","banana","grapes"];
for(let i=0;i<fruit.length;i++){
    console.log(fruit[i])
}


for(let i=1;i<=10;i++){
    if(i%2!=0){
        console.log(i);
    }
}

